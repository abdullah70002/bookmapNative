package com.cryptobookmap.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

import com.cryptobookmap.model.LiqLevel;

import java.util.ArrayList;
import java.util.List;

public class LiquidityView extends View {

    private final Paint linePaint   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bgPaint     = new Paint(Paint.ANTI_ALIAS_FLAG);

    private List<LiqLevel> levels = new ArrayList<>();

    // Chart price range — set from MainActivity
    private float priceMin = 0f;
    private float priceMax = 1f;

    private boolean visible = true;

    public LiquidityView(Context ctx) { super(ctx); init(); }
    public LiquidityView(Context ctx, AttributeSet a) { super(ctx, a); init(); }

    private void init() {
        linePaint.setStrokeWidth(1.5f);
        labelPaint.setTextSize(22f);
        labelPaint.setTypeface(Typeface.MONOSPACE);
        bgPaint.setStyle(Paint.Style.FILL);
    }

    public void setLevels(List<LiqLevel> levels, float priceMin, float priceMax) {
        this.levels   = levels;
        this.priceMin = priceMin;
        this.priceMax = priceMax;
        invalidate();
    }

    public void setVisible(boolean v) { visible = v; invalidate(); }

    @Override
    protected void onDraw(Canvas canvas) {
        if (!visible || levels.isEmpty()) return;

        int W = getWidth();
        int H = getHeight();
        float axisWidth = 62f; // price axis width
        float chartW    = W - axisWidth;

        if (priceMax <= priceMin) return;

        double maxUsd = 1;
        for (LiqLevel l : levels) if (l.usd > maxUsd) maxUsd = l.usd;

        for (LiqLevel liq : levels) {
            float y = H - (float)((liq.price - priceMin) / (priceMax - priceMin)) * H;
            if (y < 0 || y > H) continue;

            float t        = (float)(liq.usd / maxUsd);
            float barWidth = t * chartW * 0.6f;

            int bidR = 38,  bidG = 166, bidB = 154;
            int askR = 242, askG = 54,  askB = 69;
            int r = liq.isBid ? bidR : askR;
            int g = liq.isBid ? bidG : askG;
            int b = liq.isBid ? bidB : askB;

            // Fill bar
            int fillAlpha = liq.isStrong ? (int)(180 * t) : (int)(80 * t);
            bgPaint.setColor((fillAlpha << 24) | (r << 16) | (g << 8) | b);
            canvas.drawRect(chartW - barWidth, y - 3f, chartW, y + 3f, bgPaint);

            // Line
            int lineAlpha = liq.isStrong ? (int)(220 * t + 30) : (int)(120 * t + 20);
            lineAlpha = Math.min(255, lineAlpha);
            linePaint.setColor((lineAlpha << 24) | (r << 16) | (g << 8) | b);
            linePaint.setStrokeWidth(liq.isStrong ? 2f : 1.2f);
            linePaint.setPathEffect(liq.isStrong ? null :
                new android.graphics.DashPathEffect(new float[]{8f, 5f}, 0));
            canvas.drawLine(0, y, chartW, y, linePaint);
            linePaint.setPathEffect(null);

            // Left indicator bar
            bgPaint.setColor(((Math.min(255, lineAlpha + 40)) << 24) | (r << 16) | (g << 8) | b);
            canvas.drawRect(0, y - 4f, 3f, y + 4f, bgPaint);

            // Label
            String usdStr = formatUsd(liq.usd);
            String label  = (liq.isBid ? "S " : "R ") + usdStr;
            labelPaint.setColor((Math.min(255, lineAlpha + 60) << 24) | (r << 16) | (g << 8) | b);

            // Shadow
            labelPaint.setColor(0xCC0D111C);
            canvas.drawText(label, 8f, y - 5f, labelPaint);
            // Text
            labelPaint.setColor((Math.min(255, lineAlpha + 60) << 24) | (r << 16) | (g << 8) | b);
            canvas.drawText(label, 7f, y - 5f, labelPaint);
        }
    }

    private String formatUsd(double v) {
        if (v >= 1_000_000) return String.format("%.1fM", v / 1_000_000);
        if (v >= 1_000)     return String.format("%.0fK", v / 1_000);
        return String.format("%.0f", v);
    }
}
