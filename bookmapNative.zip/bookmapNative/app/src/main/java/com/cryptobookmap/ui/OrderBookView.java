package com.cryptobookmap.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class OrderBookView extends View {

    public enum Side { BID, ASK }

    private final Paint barPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txtPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dimPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);

    private List<double[]> levels = new ArrayList<>();
    private Side side = Side.BID;

    public OrderBookView(Context ctx) { super(ctx); init(); }
    public OrderBookView(Context ctx, AttributeSet a) { super(ctx, a); init(); }

    private void init() {
        txtPaint.setTypeface(Typeface.MONOSPACE);
        txtPaint.setTextSize(20f);
        dimPaint.setTypeface(Typeface.MONOSPACE);
        dimPaint.setTextSize(20f);
        dimPaint.setColor(0xFF434651);
    }

    public void setSide(Side s) { this.side = s; }

    public void setLevels(List<double[]> data) {
        this.levels = data;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (levels.isEmpty()) return;

        int W = getWidth(), H = getHeight();
        int n = Math.min(levels.size(), 16);
        float rowH = (float) H / n;
        double maxUsd = 1;
        for (int i = 0; i < n; i++) {
            double u = levels.get(i)[0] * levels.get(i)[1];
            if (u > maxUsd) maxUsd = u;
        }

        boolean isAsk = (side == Side.ASK);
        int barColor  = isAsk ? 0x1AF23645 : 0x1A26A69A;
        int txtColor  = isAsk ? 0xFFF23645 : 0xFF26A69A;

        // Asks: reverse order (lowest ask at bottom)
        List<double[]> displayList = new ArrayList<>(levels.subList(0, n));
        if (isAsk) {
            java.util.Collections.reverse(displayList);
        }

        barPaint.setColor(barColor);
        txtPaint.setColor(txtColor);

        for (int i = 0; i < displayList.size(); i++) {
            double[] row = displayList.get(i);
            double usd   = row[0] * row[1];
            float  fw    = (float)(usd / maxUsd) * (W - 4);
            float  y     = i * rowH;

            // Bar
            canvas.drawRect(W - 2 - fw, y, W - 2, y + rowH - 1, barPaint);

            // Price
            canvas.drawText(formatPrice(row[0]), 3f, y + rowH - 4f, txtPaint);

            // Qty
            canvas.drawText(formatUsd(usd), W - 2f, y + rowH - 4f,
                alignRight(dimPaint, formatUsd(usd), W - 2f));
        }
    }

    private Paint alignRight(Paint p, String text, float x) {
        p.setTextAlign(Paint.Align.RIGHT);
        return p;
    }

    private String formatPrice(double p) {
        if (p >= 100000) return String.format("%.0f", p);
        if (p >= 10000)  return String.format("%.0f", p);
        if (p >= 1000)   return String.format("%.1f", p);
        if (p >= 100)    return String.format("%.2f", p);
        if (p >= 1)      return String.format("%.4f", p);
        return String.format("%.6f", p);
    }

    private String formatUsd(double v) {
        if (v >= 1_000_000) return String.format("%.1fM", v / 1_000_000);
        if (v >= 1_000)     return String.format("%.0fK", v / 1_000);
        return String.format("%.0f", v);
    }
}
