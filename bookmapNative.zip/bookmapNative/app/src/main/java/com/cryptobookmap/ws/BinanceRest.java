package com.cryptobookmap.ws;

import android.os.Handler;
import android.os.Looper;

import com.cryptobookmap.model.Candle;

import org.json.JSONArray;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class BinanceRest {

    public interface KlineCallback {
        void onSuccess(List<Candle> candles);
        void onError(String msg);
    }

    private final OkHttpClient client = new OkHttpClient();
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public void fetchKlines(String symbol, String interval, int limit, KlineCallback cb) {
        executor.execute(() -> {
            String url = "https://api.binance.com/api/v3/klines?symbol="
                + symbol.toUpperCase()
                + "&interval=" + interval
                + "&limit=" + limit;
            Request req = new Request.Builder().url(url).build();
            try (Response resp = client.newCall(req).execute()) {
                if (!resp.isSuccessful()) {
                    mainHandler.post(() -> cb.onError("HTTP " + resp.code()));
                    return;
                }
                String body = resp.body().string();
                JSONArray arr = new JSONArray(body);
                List<Candle> candles = new ArrayList<>();
                for (int i = 0; i < arr.length(); i++) {
                    JSONArray k = arr.getJSONArray(i);
                    long   time  = k.getLong(0);
                    float  open  = (float) k.getDouble(1);
                    float  high  = (float) k.getDouble(2);
                    float  low   = (float) k.getDouble(3);
                    float  close = (float) k.getDouble(4);
                    double vol   = k.getDouble(5);
                    candles.add(new Candle(time, open, high, low, close, vol));
                }
                mainHandler.post(() -> cb.onSuccess(candles));
            } catch (IOException | org.json.JSONException e) {
                mainHandler.post(() -> cb.onError(e.getMessage()));
            }
        });
    }
}
