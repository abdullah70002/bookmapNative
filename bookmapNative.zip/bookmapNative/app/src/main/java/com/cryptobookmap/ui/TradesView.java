package com.cryptobookmap.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

import com.cryptobookmap.model.Trade;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TradesView extends View {

    private final Paint barPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txtPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss", Locale.US);

    private List<Trade> trades = new ArrayList<>();

    public TradesView(Context ctx) { super(ctx); init(); }
    public TradesView(Context ctx, AttributeSet a) { super(ctx, a); init(); }

    private void init() {
        txtPaint.setTypeface(Typeface.MONOSPACE);
        txtPaint.setTextSize(20f);
        dimPaint.setTypeface(Typeface.MONOSPACE);
        dimPaint.setTextSize(20f);
        dimPaint.setColor(0xFF3A3F50);
    }

    public void setTrades(List<Trade> t) {
        this.trades = t;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (trades.isEmpty()) return;
        int W = getWidth(), H = getHeight();
        int rowH = 34;
        int n = Math.min(trades.size(), H / rowH);
        double maxQ = 0.001;
        for (int i = 0; i < n; i++) if (trades.get(i).qty > maxQ) maxQ = trades.get(i).qty;

        for (int i = 0; i < n; i++) {
            Trade t = trades.get(i);
            float y  = i * rowH;
            float bw = (float)(t.qty / maxQ) * W * 0.35f;

            barPaint.setColor(t.isSell ? 0x12F23645 : 0x1226A69A);
            canvas.drawRect(W - bw, y, W, y + rowH - 1, barPaint);

            txtPaint.setColor(t.isSell ? 0xFFF23645 : 0xFF26A69A);
            txtPaint.setTextAlign(Paint.Align.LEFT);
            canvas.drawText(formatPrice(t.price), 3f, y + rowH - 4f, txtPaint);

            txtPaint.setColor(0xFF787B86);
            txtPaint.setTextAlign(Paint.Align.CENTER);
            String qtyStr = t.qty < 1 ? String.format("%.4f", t.qty) : String.format("%.2f", t.qty);
            canvas.drawText(qtyStr, W * 0.55f, y + rowH - 4f, txtPaint);

            dimPaint.setTextAlign(Paint.Align.RIGHT);
            canvas.drawText(sdf.format(new Date(t.time)), W - 2f, y + rowH - 4f, dimPaint);
        }
    }

    private String formatPrice(double p) {
        if (p >= 100000) return String.format("%.0f", p);
        if (p >= 10000)  return String.format("%.0f", p);
        if (p >= 1000)   return String.format("%.1f", p);
        if (p >= 100)    return String.format("%.2f", p);
        if (p >= 1)      return String.format("%.4f", p);
        return String.format("%.6f", p);
    }
}
