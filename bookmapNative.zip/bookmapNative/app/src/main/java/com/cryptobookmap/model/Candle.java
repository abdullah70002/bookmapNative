package com.cryptobookmap.model;

public class Candle {
    public long   time;
    public float  open, high, low, close;
    public double volume;

    public Candle(long time, float open, float high, float low, float close, double volume) {
        this.time   = time;
        this.open   = open;
        this.high   = high;
        this.low    = low;
        this.close  = close;
        this.volume = volume;
    }
}
