package com.cryptobookmap.model;

import java.util.ArrayList;
import java.util.List;

public class OrderBook {
    public List<double[]> bids = new ArrayList<>(); // [price, qty]
    public List<double[]> asks = new ArrayList<>();

    public void clear() {
        bids.clear();
        asks.clear();
    }

    public double getBidMaxUsd() {
        double max = 0;
        for (double[] b : bids) { double u = b[0]*b[1]; if(u>max) max=u; }
        return max;
    }

    public double getAskMaxUsd() {
        double max = 0;
        for (double[] a : asks) { double u = a[0]*a[1]; if(u>max) max=u; }
        return max;
    }

    public double getSpread() {
        if (asks.isEmpty() || bids.isEmpty()) return 0;
        return asks.get(0)[0] - bids.get(0)[0];
    }
}
