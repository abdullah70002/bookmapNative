package com.cryptobookmap.model;

public class Trade {
    public double price;
    public double qty;
    public long   time;
    public boolean isSell;

    public Trade(double price, double qty, long time, boolean isSell) {
        this.price  = price;
        this.qty    = qty;
        this.time   = time;
        this.isSell = isSell;
    }
}
