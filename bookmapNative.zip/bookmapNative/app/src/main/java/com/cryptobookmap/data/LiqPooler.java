package com.cryptobookmap.data;

import com.cryptobookmap.model.LiqLevel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LiqPooler {

    public static List<LiqLevel> pool(
            List<double[]> bids,
            List<double[]> asks,
            double minUsd,
            boolean poolOn,
            double poolPct) {

        List<LiqLevel> result = new ArrayList<>();

        List<double[]> filteredBids = new ArrayList<>();
        List<double[]> filteredAsks = new ArrayList<>();

        for (double[] b : bids) if (b[0]*b[1] >= minUsd) filteredBids.add(b);
        for (double[] a : asks) if (a[0]*a[1] >= minUsd) filteredAsks.add(a);

        if (poolOn) {
            result.addAll(poolLevels(filteredBids, poolPct, true));
            result.addAll(poolLevels(filteredAsks, poolPct, false));
        } else {
            double avgBid = avgUsd(filteredBids);
            double avgAsk = avgUsd(filteredAsks);
            for (double[] b : filteredBids)
                result.add(new LiqLevel(b[0], b[0]*b[1], true, b[0]*b[1] > avgBid * 2));
            for (double[] a : filteredAsks)
                result.add(new LiqLevel(a[0], a[0]*a[1], false, a[0]*a[1] > avgAsk * 2));
        }

        return result;
    }

    private static List<LiqLevel> poolLevels(List<double[]> levels, double pct, boolean isBid) {
        if (levels.isEmpty()) return new ArrayList<>();

        // Sort: bids desc, asks asc
        List<double[]> sorted = new ArrayList<>(levels);
        if (isBid) {
            Collections.sort(sorted, (a, b) -> Double.compare(b[0], a[0]));
        } else {
            Collections.sort(sorted, (a, b) -> Double.compare(a[0], b[0]));
        }

        List<double[]> clusters = new ArrayList<>(); // [anchorPrice, totalUsd, count]
        double half = (pct / 100.0) / 2.0;

        for (double[] lv : sorted) {
            double p = lv[0];
            double u = lv[0] * lv[1];
            boolean merged = false;

            for (double[] cl : clusters) {
                double anchor = cl[0];
                double lo = anchor * (1 - half);
                double hi = anchor * (1 + half);
                if (p >= lo && p <= hi) {
                    cl[1] += u;
                    cl[2] += 1;
                    merged = true;
                    break;
                }
            }
            if (!merged) {
                clusters.add(new double[]{p, u, 1});
            }
        }

        // Calculate average for "strong" detection
        double avgUsd = 0;
        for (double[] cl : clusters) avgUsd += cl[1];
        avgUsd = clusters.isEmpty() ? 1 : avgUsd / clusters.size();

        List<LiqLevel> result = new ArrayList<>();
        for (double[] cl : clusters) {
            result.add(new LiqLevel(cl[0], cl[1], isBid, cl[1] > avgUsd * 2));
        }
        return result;
    }

    private static double avgUsd(List<double[]> levels) {
        if (levels.isEmpty()) return 1;
        double sum = 0;
        for (double[] l : levels) sum += l[0]*l[1];
        return sum / levels.size();
    }
}
