package com.cryptobookmap.model;

public class LiqLevel {
    public double price;
    public double usd;
    public boolean isBid;
    public boolean isStrong;

    public LiqLevel(double price, double usd, boolean isBid, boolean isStrong) {
        this.price    = price;
        this.usd      = usd;
        this.isBid    = isBid;
        this.isStrong = isStrong;
    }
}
