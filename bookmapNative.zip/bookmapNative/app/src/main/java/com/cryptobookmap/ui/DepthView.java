package com.cryptobookmap.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

import java.util.List;

public class DepthView extends View {

    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txtPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dimPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    private double totalBid = 0, totalAsk = 0;
    private double maxBidUsd = 0, maxAskUsd = 0;

    public DepthView(Context ctx) { super(ctx); init(); }
    public DepthView(Context ctx, AttributeSet a) { super(ctx, a); init(); }

    private void init() {
        txtPaint.setTypeface(Typeface.MONOSPACE);
        txtPaint.setTextSize(24f);
        dimPaint.setTypeface(Typeface.MONOSPACE);
        dimPaint.setTextSize(20f);
        dimPaint.setColor(0xFF787B86);
    }

    public void setData(double totalBid, double totalAsk, double maxBidUsd, double maxAskUsd) {
        this.totalBid  = totalBid;
        this.totalAsk  = totalAsk;
        this.maxBidUsd = maxBidUsd;
        this.maxAskUsd = maxAskUsd;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int W = getWidth(), H = getHeight();
        int pad = 24;
        int trackH = 20;
        int rowGap  = 60;
        int y = pad + 30;

        // Title
        dimPaint.setTextAlign(Paint.Align.LEFT);
        canvas.drawText("MARKET DEPTH", pad, y, dimPaint);
        y += rowGap;

        double total = totalBid + totalAsk;
        float bidPct = total > 0 ? (float)(totalBid / total) : 0.5f;

        // BID bar
        txtPaint.setColor(0xFF26A69A);
        txtPaint.setTextAlign(Paint.Align.LEFT);
        canvas.drawText("Total BID", pad, y, txtPaint);
        txtPaint.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText(formatUsd(totalBid), W - pad, y, txtPaint);
        y += 28;
        rect.set(pad, y, pad + (W - pad * 2) * bidPct, y + trackH);
        fillPaint.setColor(0xFF26A69A);
        canvas.drawRoundRect(rect, 5f, 5f, fillPaint);
        fillPaint.setColor(0xFF2A2E39);
        rect.set(pad + (W - pad * 2) * bidPct, y, W - pad, y + trackH);
        canvas.drawRoundRect(rect, 5f, 5f, fillPaint);
        y += rowGap;

        // ASK bar
        txtPaint.setColor(0xFFF23645);
        txtPaint.setTextAlign(Paint.Align.LEFT);
        canvas.drawText("Total ASK", pad, y, txtPaint);
        txtPaint.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText(formatUsd(totalAsk), W - pad, y, txtPaint);
        y += 28;
        rect.set(pad, y, pad + (W - pad * 2) * (1 - bidPct), y + trackH);
        fillPaint.setColor(0xFFF23645);
        canvas.drawRoundRect(rect, 5f, 5f, fillPaint);
        fillPaint.setColor(0xFF2A2E39);
        rect.set(pad + (W - pad * 2) * (1 - bidPct), y, W - pad, y + trackH);
        canvas.drawRoundRect(rect, 5f, 5f, fillPaint);
        y += rowGap;

        // Ratio bar
        int ratioTrackH = 24;
        rect.set(pad, y, pad + (W - pad * 2) * bidPct, y + ratioTrackH);
        fillPaint.setColor(0xFF26A69A);
        canvas.drawRoundRect(rect, 6f, 6f, fillPaint);
        rect.set(pad + (W - pad * 2) * bidPct, y, W - pad, y + ratioTrackH);
        fillPaint.setColor(0xFFF23645);
        canvas.drawRoundRect(rect, 6f, 6f, fillPaint);
        y += ratioTrackH + 10;
        dimPaint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText(String.format("BID %.0f%%  /  ASK %.0f%%",
            bidPct * 100, (1 - bidPct) * 100), W / 2f, y, dimPaint);
        y += rowGap;

        // Max levels
        txtPaint.setColor(0xFFD1D4DC);
        txtPaint.setTextAlign(Paint.Align.LEFT);
        canvas.drawText("MAX BID $", pad, y, txtPaint);
        txtPaint.setColor(0xFF26A69A);
        canvas.drawText(formatUsd(maxBidUsd), pad + 180, y, txtPaint);

        txtPaint.setColor(0xFFD1D4DC);
        canvas.drawText("MAX ASK $", W / 2, y, txtPaint);
        txtPaint.setColor(0xFFF23645);
        canvas.drawText(formatUsd(maxAskUsd), W / 2 + 180, y, txtPaint);
    }

    private String formatUsd(double v) {
        if (v >= 1_000_000_000) return String.format("%.1fB", v / 1_000_000_000);
        if (v >= 1_000_000)     return String.format("%.1fM", v / 1_000_000);
        if (v >= 1_000)         return String.format("%.0fK", v / 1_000);
        return String.format("%.0f", v);
    }
}
