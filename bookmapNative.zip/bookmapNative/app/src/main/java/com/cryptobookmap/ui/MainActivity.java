package com.cryptobookmap.ui;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.cryptobookmap.R;
import com.cryptobookmap.data.LiqPooler;
import com.cryptobookmap.model.Candle;
import com.cryptobookmap.model.LiqLevel;
import com.cryptobookmap.model.OrderBook;
import com.cryptobookmap.model.Trade;
import com.cryptobookmap.ws.BinanceRest;
import com.cryptobookmap.ws.BinanceWs;
import com.github.mikephil.charting.charts.CombinedChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.CandleData;
import com.github.mikephil.charting.data.CandleDataSet;
import com.github.mikephil.charting.data.CandleEntry;
import com.github.mikephil.charting.data.CombinedData;
import com.github.mikephil.charting.formatter.ValueFormatter;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    // ── Views ──
    private CombinedChart chart;
    private LiquidityView liqView;
    private OrderBookView obAsks, obBids;
    private TradesView    panelTrades;
    private DepthView     panelDepth;
    private LinearLayout  panelOb;
    private FrameLayout   loadingOverlay;
    private TextView tvPrice, tvChange, tvSymbol, tvHigh, tvLow, tvVol;
    private TextView tvBidMax, tvAskMax, tvSpread, tvSpread2, tvMidPrice;
    private TextView tvLoadSym, tvLoadMsg, tvWsLabel;
    private View     wsDot;

    // ── Timeframe buttons ──
    private final int[] TF_IDS = {R.id.tf1m, R.id.tf5m, R.id.tf15m, R.id.tf1h, R.id.tf4h, R.id.tf1d};

    // ── State ──
    private String sym = "BTCUSDT";
    private String tf  = "5m";
    private double currentPrice = 0;
    private boolean liqOn  = true;
    private boolean poolOn = true;

    // ── Data ──
    private final OrderBook ob = new OrderBook();
    private final List<Trade> trades = new ArrayList<>();
    private final List<Candle> candles = new ArrayList<>();

    // ── Network ──
    private final BinanceWs   ws   = new BinanceWs();
    private final BinanceRest rest = new BinanceRest();

    // ── Chart data ──
    private final List<CandleEntry> candleEntries = new ArrayList<>();
    private final List<BarEntry>    volEntries    = new ArrayList<>();
    private CandleDataSet candleSet;
    private BarDataSet    volSet;

    // ── Notifications ──
    private int notifId = 100;
    private static final String CH_ALERTS = "price_alerts";
    private static final String CH_BG     = "bg_service";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                             WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);

        bindViews();
        setupChart();
        setupTabs();
        setupTimeframes();
        setupControls();
        createNotifChannels();
        showBgNotif();

        ws.setListener(wsListener);
        loadSymbol(sym, tf);
    }

    @Override protected void onResume()  { super.onResume();  setImmersive(); }
    @Override protected void onPause()   { super.onPause(); }
    @Override protected void onDestroy() {
        ws.disconnect();
        cancelBgNotif();
        super.onDestroy();
    }
    @Override public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) setImmersive();
    }

    // ════════════════════════════════════════
    //  BIND VIEWS
    // ════════════════════════════════════════
    private void bindViews() {
        chart         = findViewById(R.id.chart);
        liqView       = findViewById(R.id.liqView);
        obAsks        = findViewById(R.id.obAsks);
        obBids        = findViewById(R.id.obBids);
        panelTrades   = findViewById(R.id.panelTrades);
        panelDepth    = findViewById(R.id.panelDepth);
        panelOb       = findViewById(R.id.panelOb);
        loadingOverlay= findViewById(R.id.loadingOverlay);
        tvPrice       = findViewById(R.id.tvPrice);
        tvChange      = findViewById(R.id.tvChange);
        tvSymbol      = findViewById(R.id.tvSymbol);
        tvHigh        = findViewById(R.id.tvHigh);
        tvLow         = findViewById(R.id.tvLow);
        tvVol         = findViewById(R.id.tvVol);
        tvBidMax      = findViewById(R.id.tvBidMax);
        tvAskMax      = findViewById(R.id.tvAskMax);
        tvSpread      = findViewById(R.id.tvSpread);
        tvSpread2     = findViewById(R.id.tvSpread2);
        tvMidPrice    = findViewById(R.id.tvMidPrice);
        tvLoadSym     = findViewById(R.id.tvLoadSym);
        tvLoadMsg     = findViewById(R.id.tvLoadMsg);
        tvWsLabel     = findViewById(R.id.tvWsLabel);
        wsDot         = findViewById(R.id.wsDot);

        obAsks.setSide(OrderBookView.Side.ASK);
        obBids.setSide(OrderBookView.Side.BID);
    }

    // ════════════════════════════════════════
    //  CHART SETUP
    // ════════════════════════════════════════
    private void setupChart() {
        chart.setBackgroundColor(0xFF131722);
        chart.setDrawGridBackground(false);
        chart.setDrawBorders(false);
        chart.getDescription().setEnabled(false);
        chart.getLegend().setEnabled(false);
        chart.setScaleEnabled(true);
        chart.setPinchZoom(false);
        chart.setDoubleTapToZoomEnabled(false);
        chart.setHighlightPerTapEnabled(false);

        // X Axis
        XAxis x = chart.getXAxis();
        x.setPosition(XAxis.XAxisPosition.BOTTOM);
        x.setDrawGridLines(true);
        x.setGridColor(0xFF1A1F2C);
        x.setTextColor(0xFF787B86);
        x.setTextSize(8f);
        x.setLabelCount(5);
        x.setValueFormatter(new ValueFormatter() {
            final SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.US);
            @Override public String getFormattedValue(float value) {
                return sdf.format(new Date((long) value * 1000));
            }
        });

        // Y Axis (right)
        YAxis yr = chart.getAxisRight();
        yr.setDrawGridLines(true);
        yr.setGridColor(0xFF1A1F2C);
        yr.setTextColor(0xFF787B86);
        yr.setTextSize(8f);
        yr.setDrawZeroLine(false);

        // Y Axis left — volume
        YAxis yl = chart.getAxisLeft();
        yl.setEnabled(false);

        // Init datasets
        candleSet = new CandleDataSet(candleEntries, "candles");
        candleSet.setColor(Color.WHITE);
        candleSet.setDecreasingColor(0xFFF23645);
        candleSet.setIncreasingColor(0xFF26A69A);
        candleSet.setDecreasingPaintStyle(android.graphics.Paint.Style.FILL);
        candleSet.setIncreasingPaintStyle(android.graphics.Paint.Style.FILL);
        candleSet.setShadowColor(0xFF787B86);
        candleSet.setShadowWidth(1f);
        candleSet.setDrawValues(false);
        candleSet.setHighlightEnabled(false);

        volSet = new BarDataSet(volEntries, "vol");
        volSet.setDrawValues(false);
        volSet.setHighlightEnabled(false);
    }

    // ════════════════════════════════════════
    //  TIMEFRAMES
    // ════════════════════════════════════════
    private void setupTimeframes() {
        int[] ids = TF_IDS;
        String[] tfs = {"1m","5m","15m","1h","4h","1d"};
        for (int i = 0; i < ids.length; i++) {
            final String tfVal = tfs[i];
            TextView btn = findViewById(ids[i]);
            if (btn == null) continue;
            btn.setOnClickListener(v -> switchTf(tfVal));
        }
        updateTfUI();
    }

    private void switchTf(String newTf) {
        tf = newTf;
        updateTfUI();
        candleEntries.clear();
        volEntries.clear();
        showLoading(true);
        ws.changeTf(tf);
        rest.fetchKlines(sym, tf, 200, klinesCallback);
    }

    private void updateTfUI() {
        String[] tfs = {"1m","5m","15m","1h","4h","1d"};
        for (int i = 0; i < TF_IDS.length; i++) {
            TextView btn = findViewById(TF_IDS[i]);
            if (btn == null) continue;
            boolean on = tfs[i].equals(tf);
            btn.setBackground(on
                ? getDrawable(R.drawable.bg_tf_on)
                : null);
            btn.setTextColor(on ? 0xFFFFFFFF : 0xFF787B86);
        }
    }

    // ════════════════════════════════════════
    //  CONTROLS
    // ════════════════════════════════════════
    private void setupControls() {
        TextView btnLiq  = findViewById(R.id.btnLiq);
        TextView btnPool = findViewById(R.id.btnPool);
        TextView btnAuto = findViewById(R.id.btnAuto);

        if (btnLiq  != null) btnLiq.setOnClickListener(v  -> toggleLiq());
        if (btnPool != null) btnPool.setOnClickListener(v -> togglePool());
        if (btnAuto != null) btnAuto.setOnClickListener(v -> fitChart());
    }

    private void toggleLiq() {
        liqOn = !liqOn;
        liqView.setVisibility(liqOn ? View.VISIBLE : View.GONE);
        TextView btn = findViewById(R.id.btnLiq);
        if (btn != null) btn.setBackground(liqOn
            ? getDrawable(R.drawable.bg_ctrl_on)
            : getDrawable(R.drawable.bg_ctrl_off));
    }

    private void togglePool() {
        poolOn = !poolOn;
        TextView btn = findViewById(R.id.btnPool);
        if (btn != null) btn.setBackground(poolOn
            ? getDrawable(R.drawable.bg_ctrl_on)
            : getDrawable(R.drawable.bg_ctrl_off));
        refreshLiquidity();
    }

    private void fitChart() {
        chart.fitScreen();
        chart.getAxisRight().resetAxisMinimum();
        chart.getAxisRight().resetAxisMaximum();
        chart.invalidate();
    }

    // ════════════════════════════════════════
    //  TABS
    // ════════════════════════════════════════
    private void setupTabs() {
        TextView tabOb     = findViewById(R.id.tabOb);
        TextView tabTrades = findViewById(R.id.tabTrades);
        TextView tabDepth  = findViewById(R.id.tabDepth);
        if (tabOb     != null) tabOb.setOnClickListener(v     -> switchTab(0));
        if (tabTrades != null) tabTrades.setOnClickListener(v -> switchTab(1));
        if (tabDepth  != null) tabDepth.setOnClickListener(v  -> switchTab(2));
    }

    private void switchTab(int idx) {
        panelOb.setVisibility(idx == 0 ? View.VISIBLE : View.GONE);
        panelTrades.setVisibility(idx == 1 ? View.VISIBLE : View.GONE);
        panelDepth.setVisibility(idx == 2 ? View.VISIBLE : View.GONE);

        int[] tabIds = {R.id.tabOb, R.id.tabTrades, R.id.tabDepth};
        for (int i = 0; i < tabIds.length; i++) {
            TextView t = findViewById(tabIds[i]);
            if (t != null) t.setTextColor(i == idx ? 0xFF2962FF : 0xFF787B86);
        }
    }

    // ════════════════════════════════════════
    //  LOAD SYMBOL
    // ════════════════════════════════════════
    private void loadSymbol(String s, String timeframe) {
        sym = s.toUpperCase();
        tf  = timeframe;
        tvSymbol.setText(symDisplay(sym));
        tvLoadSym.setText(sym);
        showLoading(true);
        ob.clear(); trades.clear(); candleEntries.clear(); volEntries.clear();
        ws.disconnect();
        rest.fetchKlines(sym, tf, 200, klinesCallback);
    }

    private final BinanceRest.KlineCallback klinesCallback = new BinanceRest.KlineCallback() {
        @Override public void onSuccess(List<Candle> data) {
            candles.clear();
            candles.addAll(data);
            candleEntries.clear();
            volEntries.clear();
            for (Candle c : candles) {
                float x = c.time / 1000f;
                candleEntries.add(new CandleEntry(x, c.high, c.low, c.open, c.close));
                boolean bull = c.close >= c.open;
                volEntries.add(new BarEntry(x, (float)c.volume,
                    bull ? 0x2F26A69A : 0x2FF23645));
            }
            refreshChart();
            showLoading(false);
            ws.connect(sym, tf);
        }
        @Override public void onError(String msg) {
            tvLoadMsg.setText("خطأ: " + msg);
        }
    };

    // ════════════════════════════════════════
    //  CHART REFRESH
    // ════════════════════════════════════════
    private void refreshChart() {
        candleSet.notifyDataSetChanged();
        volSet.notifyDataSetChanged();

        CandleData cd = new CandleData(candleSet);
        BarData    bd = new BarData(volSet);
        bd.setBarWidth(0.8f);

        CombinedData combined = new CombinedData();
        combined.setData(cd);
        combined.setData(bd);

        chart.setData(combined);
        chart.notifyDataSetChanged();
        chart.invalidate();
        chart.moveViewToX(candleEntries.isEmpty() ? 0 :
            candleEntries.get(candleEntries.size()-1).getX());
    }

    // ════════════════════════════════════════
    //  WS LISTENER
    // ════════════════════════════════════════
    private final BinanceWs.Listener wsListener = new BinanceWs.Listener() {

        @Override
        public void onCandle(long time, double open, double high, double low, double close,
                             double vol, boolean closed) {
            double prev = currentPrice;
            currentPrice = close;
            float x = time / 1000f;

            // Update or add candle entry
            boolean found = false;
            for (int i = candleEntries.size() - 1; i >= Math.max(0, candleEntries.size()-3); i--) {
                if (Math.abs(candleEntries.get(i).getX() - x) < 1) {
                    candleEntries.set(i, new CandleEntry(x,
                        (float)high, (float)low, (float)open, (float)close));
                    boolean bull = close >= open;
                    volEntries.set(i, new BarEntry(x, (float)vol,
                        bull ? 0x2F26A69A : 0x2FF23645));
                    found = true;
                    break;
                }
            }
            if (!found) {
                candleEntries.add(new CandleEntry(x,
                    (float)high, (float)low, (float)open, (float)close));
                boolean bull = close >= open;
                volEntries.add(new BarEntry(x, (float)vol,
                    bull ? 0x2F26A69A : 0x2FF23645));
            }
            refreshChart();
            updatePriceUI(close, prev);
        }

        @Override
        public void onOrderBook(List<double[]> bids, List<double[]> asks) {
            ob.bids.clear(); ob.bids.addAll(bids);
            ob.asks.clear(); ob.asks.addAll(asks);
            updateObUI();
            refreshLiquidity();
        }

        @Override
        public void onTrade(double price, double qty, long time, boolean isSell) {
            trades.add(0, new Trade(price, qty, time, isSell));
            if (trades.size() > 200) trades.remove(trades.size()-1);
            panelTrades.setTrades(trades);
        }

        @Override
        public void on24h(double high, double low, double vol, double open) {
            tvHigh.setText(formatPrice(high));
            tvLow.setText(formatPrice(low));
            tvVol.setText(formatVol(vol));
        }

        @Override
        public void onConnected(boolean on) {
            wsDot.setBackground(getDrawable(on ? R.drawable.dot_connected : R.drawable.dot_disconnected));
            tvWsLabel.setText(on ? "LIVE" : "—");
        }
    };

    // ════════════════════════════════════════
    //  UI UPDATES
    // ════════════════════════════════════════
    private void updatePriceUI(double price, double prev) {
        tvPrice.setText(formatPrice(price));
        tvPrice.setTextColor(price >= prev ? 0xFF26A69A : 0xFFF23645);
        tvMidPrice.setText(formatPrice(price));
        tvMidPrice.setTextColor(0xFF26A69A);
    }

    private void updateObUI() {
        obAsks.setLevels(ob.asks);
        obBids.setLevels(ob.bids);

        if (!ob.asks.isEmpty() && !ob.bids.isEmpty()) {
            double spread = ob.getSpread();
            tvSpread.setText("spread " + formatPrice(spread));
            tvSpread2.setText(formatPrice(spread));
        }
        tvBidMax.setText(formatVol(ob.getBidMaxUsd()));
        tvAskMax.setText(formatVol(ob.getAskMaxUsd()));

        // Depth
        double tBid = 0, tAsk = 0;
        for (double[] b : ob.bids) tBid += b[0]*b[1];
        for (double[] a : ob.asks) tAsk += a[0]*a[1];
        panelDepth.setData(tBid, tAsk, ob.getBidMaxUsd(), ob.getAskMaxUsd());
    }

    private void refreshLiquidity() {
        if (!liqOn) return;
        List<LiqLevel> levels = LiqPooler.pool(ob.bids, ob.asks, 50000, poolOn, 0.05);

        // Get chart visible price range
        float min = (float) chart.getAxisRight().getAxisMinimum();
        float max = (float) chart.getAxisRight().getAxisMaximum();
        if (max <= min) {
            // fallback
            if (!candleEntries.isEmpty()) {
                min = candleEntries.get(0).getLow();
                max = candleEntries.get(0).getHigh();
                for (CandleEntry e : candleEntries) {
                    if (e.getLow()  < min) min = e.getLow();
                    if (e.getHigh() > max) max = e.getHigh();
                }
            }
        }
        liqView.setLevels(levels, min, max);
    }

    // ════════════════════════════════════════
    //  HELPERS
    // ════════════════════════════════════════
    private void showLoading(boolean show) {
        loadingOverlay.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    @SuppressWarnings("deprecation")
    private void setImmersive() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    private String symDisplay(String s) {
        if (s.endsWith("USDT")) return s.substring(0, s.length()-4) + "/USDT";
        if (s.endsWith("BTC"))  return s.substring(0, s.length()-3) + "/BTC";
        return s;
    }

    private String formatPrice(double p) {
        if (p >= 100000) return String.format(Locale.US, "%.0f", p);
        if (p >= 10000)  return String.format(Locale.US, "%.0f", p);
        if (p >= 1000)   return String.format(Locale.US, "%.1f", p);
        if (p >= 100)    return String.format(Locale.US, "%.2f", p);
        if (p >= 1)      return String.format(Locale.US, "%.4f", p);
        return String.format(Locale.US, "%.6f", p);
    }

    private String formatVol(double v) {
        if (v >= 1e9) return String.format(Locale.US, "%.1fB", v/1e9);
        if (v >= 1e6) return String.format(Locale.US, "%.1fM", v/1e6);
        if (v >= 1e3) return String.format(Locale.US, "%.0fK", v/1e3);
        return String.format(Locale.US, "%.0f", v);
    }

    // ════════════════════════════════════════
    //  NOTIFICATIONS
    // ════════════════════════════════════════
    private void createNotifChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            NotificationChannel alerts = new NotificationChannel(CH_ALERTS,
                "تنبيهات السعر", NotificationManager.IMPORTANCE_HIGH);
            alerts.enableVibration(true);
            nm.createNotificationChannel(alerts);
            NotificationChannel bg = new NotificationChannel(CH_BG,
                "BookmapPro نشط", NotificationManager.IMPORTANCE_MIN);
            bg.setSound(null, null);
            nm.createNotificationChannel(bg);
        }
    }

    private void showBgNotif() {
        try {
            Intent i = new Intent(this, MainActivity.class);
            int f = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                ? PendingIntent.FLAG_IMMUTABLE : 0;
            PendingIntent pi = PendingIntent.getActivity(this, 0, i, f);
            Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CH_BG)
                : new Notification.Builder(this);
            Notification n = b.setContentTitle("BookmapPro")
                .setContentText("يراقب السوق في الخلفية")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pi).setOngoing(true).build();
            nm().notify(1, n);
        } catch (Exception e) {}
    }

    private void cancelBgNotif() {
        try { nm().cancel(1); } catch (Exception e) {}
    }

    public void pushNotif(String title, String body) {
        try {
            Intent i = new Intent(this, MainActivity.class);
            int f = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                ? PendingIntent.FLAG_IMMUTABLE : 0;
            PendingIntent pi = PendingIntent.getActivity(this, 0, i, f);
            Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CH_ALERTS)
                : new Notification.Builder(this);
            Notification n = b.setContentTitle(title).setContentText(body)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentIntent(pi).setAutoCancel(true).build();
            nm().notify(notifId++, n);
        } catch (Exception e) {}
    }

    private NotificationManager nm() {
        return (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
    }
}
