package com.cryptobookmap.ws;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

public class BinanceWs {

    public interface Listener {
        void onCandle(long time, double open, double high, double low, double close, double vol, boolean closed);
        void onOrderBook(List<double[]> bids, List<double[]> asks);
        void onTrade(double price, double qty, long time, boolean isSell);
        void on24h(double high, double low, double vol, double open);
        void onConnected(boolean on);
    }

    private static final String TAG = "BinanceWs";
    private final OkHttpClient client;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private WebSocket wsKline, wsDepth, wsTrade, ws24h;
    private Listener listener;
    private String sym = "btcusdt";
    private String tf  = "5m";
    private boolean intentionalClose = false;
    private int reconnectDelay = 3000;

    public BinanceWs() {
        client = new OkHttpClient.Builder()
            .pingInterval(20, TimeUnit.SECONDS)
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build();
    }

    public void setListener(Listener l) { this.listener = l; }

    public void connect(String symbol, String timeframe) {
        sym = symbol.toLowerCase();
        tf  = timeframe;
        intentionalClose = false;
        openAll();
    }

    public void disconnect() {
        intentionalClose = true;
        closeAll();
    }

    public void changeTf(String timeframe) {
        tf = timeframe;
        intentionalClose = true;
        if (wsKline != null) wsKline.close(1000, "tf change");
        intentionalClose = false;
        openKline();
    }

    // ── Open all streams ──
    private void openAll() {
        openKline();
        openDepth();
        openTrade();
        open24h();
    }

    private void closeAll() {
        try { if (wsKline  != null) wsKline.close(1000,  "close"); } catch (Exception e) {}
        try { if (wsDepth  != null) wsDepth.close(1000,  "close"); } catch (Exception e) {}
        try { if (wsTrade  != null) wsTrade.close(1000,  "close"); } catch (Exception e) {}
        try { if (ws24h    != null) ws24h.close(1000,    "close"); } catch (Exception e) {}
    }

    // ── Kline stream ──
    private void openKline() {
        String url = "wss://stream.binance.com:9443/ws/" + sym + "@kline_" + tf;
        Request req = new Request.Builder().url(url).build();
        wsKline = client.newWebSocket(req, new WebSocketListener() {
            @Override public void onOpen(WebSocket ws, Response r) {
                notifyConnected(true);
            }
            @Override public void onMessage(WebSocket ws, String text) {
                parseKline(text);
            }
            @Override public void onFailure(WebSocket ws, Throwable t, Response r) {
                notifyConnected(false);
                if (!intentionalClose) scheduleReconnect(() -> openKline());
            }
            @Override public void onClosed(WebSocket ws, int code, String reason) {
                if (!intentionalClose) scheduleReconnect(() -> openKline());
            }
        });
    }

    // ── Depth stream ──
    private void openDepth() {
        String url = "wss://stream.binance.com:9443/ws/" + sym + "@depth20@100ms";
        Request req = new Request.Builder().url(url).build();
        wsDepth = client.newWebSocket(req, new WebSocketListener() {
            @Override public void onMessage(WebSocket ws, String text) {
                parseDepth(text);
            }
            @Override public void onFailure(WebSocket ws, Throwable t, Response r) {
                if (!intentionalClose) scheduleReconnect(() -> openDepth());
            }
            @Override public void onClosed(WebSocket ws, int code, String reason) {
                if (!intentionalClose) scheduleReconnect(() -> openDepth());
            }
        });
    }

    // ── Trade stream ──
    private void openTrade() {
        String url = "wss://stream.binance.com:9443/ws/" + sym + "@aggTrade";
        Request req = new Request.Builder().url(url).build();
        wsTrade = client.newWebSocket(req, new WebSocketListener() {
            @Override public void onMessage(WebSocket ws, String text) {
                parseTrade(text);
            }
            @Override public void onFailure(WebSocket ws, Throwable t, Response r) {
                if (!intentionalClose) scheduleReconnect(() -> openTrade());
            }
            @Override public void onClosed(WebSocket ws, int code, String reason) {
                if (!intentionalClose) scheduleReconnect(() -> openTrade());
            }
        });
    }

    // ── 24h ticker ──
    private void open24h() {
        String url = "wss://stream.binance.com:9443/ws/" + sym + "@ticker";
        Request req = new Request.Builder().url(url).build();
        ws24h = client.newWebSocket(req, new WebSocketListener() {
            @Override public void onMessage(WebSocket ws, String text) {
                parse24h(text);
            }
            @Override public void onFailure(WebSocket ws, Throwable t, Response r) {
                if (!intentionalClose) scheduleReconnect(() -> open24h());
            }
            @Override public void onClosed(WebSocket ws, int code, String reason) {
                if (!intentionalClose) scheduleReconnect(() -> open24h());
            }
        });
    }

    // ── Parsers ──
    private void parseKline(String text) {
        try {
            JSONObject j = new JSONObject(text);
            JSONObject k = j.getJSONObject("k");
            long   time   = k.getLong("t");
            double open   = k.getDouble("o");
            double high   = k.getDouble("h");
            double low    = k.getDouble("l");
            double close  = k.getDouble("c");
            double vol    = k.getDouble("v");
            boolean closed = k.getBoolean("x");
            if (listener != null)
                mainHandler.post(() -> listener.onCandle(time, open, high, low, close, vol, closed));
        } catch (Exception e) { Log.e(TAG, "parseKline: " + e.getMessage()); }
    }

    private void parseDepth(String text) {
        try {
            JSONObject j = new JSONObject(text);
            JSONArray jBids = j.getJSONArray("bids");
            JSONArray jAsks = j.getJSONArray("asks");

            List<double[]> bids = new ArrayList<>();
            List<double[]> asks = new ArrayList<>();

            for (int i = 0; i < jBids.length(); i++) {
                JSONArray row = jBids.getJSONArray(i);
                double p = Double.parseDouble(row.getString(0));
                double q = Double.parseDouble(row.getString(1));
                if (q > 0) bids.add(new double[]{p, q});
            }
            for (int i = 0; i < jAsks.length(); i++) {
                JSONArray row = jAsks.getJSONArray(i);
                double p = Double.parseDouble(row.getString(0));
                double q = Double.parseDouble(row.getString(1));
                if (q > 0) asks.add(new double[]{p, q});
            }

            // Sort: bids descending, asks ascending
            Collections.sort(bids, (a, b) -> Double.compare(b[0], a[0]));
            Collections.sort(asks, (a, b) -> Double.compare(a[0], b[0]));

            if (listener != null)
                mainHandler.post(() -> listener.onOrderBook(bids, asks));
        } catch (Exception e) { Log.e(TAG, "parseDepth: " + e.getMessage()); }
    }

    private void parseTrade(String text) {
        try {
            JSONObject j = new JSONObject(text);
            double price  = j.getDouble("p");
            double qty    = j.getDouble("q");
            long   time   = j.getLong("T");
            boolean sell  = j.getBoolean("m"); // maker = sell
            if (listener != null)
                mainHandler.post(() -> listener.onTrade(price, qty, time, sell));
        } catch (Exception e) { Log.e(TAG, "parseTrade: " + e.getMessage()); }
    }

    private void parse24h(String text) {
        try {
            JSONObject j = new JSONObject(text);
            double high = j.getDouble("h");
            double low  = j.getDouble("l");
            double vol  = j.getDouble("q"); // quote volume
            double open = j.getDouble("o");
            if (listener != null)
                mainHandler.post(() -> listener.on24h(high, low, vol, open));
        } catch (Exception e) { Log.e(TAG, "parse24h: " + e.getMessage()); }
    }

    // ── Helpers ──
    private void notifyConnected(boolean on) {
        if (listener != null)
            mainHandler.post(() -> listener.onConnected(on));
    }

    private void scheduleReconnect(Runnable action) {
        mainHandler.postDelayed(() -> {
            if (!intentionalClose) action.run();
        }, reconnectDelay);
    }
}
